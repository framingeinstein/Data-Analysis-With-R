library(ggplot2)
library(stats)
setwd("/Users/jason/Documents/projects/ODU/PHYS413/LAB-A/")
data <- read.table("Magnetization of a Ferromagnet.txt", header = TRUE, sep = ",")
attach(data)
#M =  M0 [1-1/(T/TC)2]
#model <- deriv(~ , c('M','T'),function(B,T,X){})
fit  <- nls(log(y)~I(B*log(x-T)), start=list(B=0.5, T=1000.00))
#m <- summary(fit)
#se <- m$sigma
#se <- se + .04
#limits <- aes(x = x, ymax = y + se, ymin=y - se)
#bars <- geom_errorbar(limits, width=0.002)
s <- stat_smooth(aes(x=x, y=y), se = TRUE)
d <- ggplot(data) + geom_point(aes(x=x,y=y)) + scale_y_log10() + scale_x_log10() + ggtitle("Magnetization of Ferromagnet") + xlab("Thickness (mm)") + ylab("Count Rate (counts per second)")
d <- d + s 
#d <- d + bars
print(d)
#a <- ggplotRegression(fit)
#print(a)

