setwd("/Users/jason/Documents/projects/ODU/PHYS413/LAB-A/")
source("functions.R")
library(ggplot2)
data <- read.table("Electrical Cunductivity of Semiconductor.txt", header = TRUE, sep = ",")
attach(data)
fit  <- lm(log(y)~I(1/x))
m <- summary(fit)
se <- m$sigma
se <- se + .04
limits <- aes(x = x, ymax = y + se, ymin=y - se)
bars <- geom_errorbar(limits, width=20)
s <- stat_smooth(aes(x=x, y=y), se = TRUE)
d <- ggplot(data) + geom_point(aes(x=x,y=y)) + ggtitle("Electrical Conductivity of a Semiconductor") + xlab("Temperature (K)") + ylab("ln(Conductivity (ohms/cm))")
d <- d + s + bars
#print(d)
#eq <- function(x, ,) {e^(-)}
a <- ggplotRegression(fit)
print(a)