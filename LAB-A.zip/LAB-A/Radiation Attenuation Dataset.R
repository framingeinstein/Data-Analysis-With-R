library(ggplot2)
setwd("/Users/jason/Documents/projects/ODU/PHYS413/LAB-A/")
data <- read.table("Radiation Attenuation.txt", header = TRUE, sep = ",")
attach(data)
fit  <- lm(log(y)~x)
m <- summary(fit)
se <- m$sigma
se <- se + .04
limits <- aes(x = x, ymax = y + se, ymin=y - se)
bars <- geom_errorbar(limits, width=0.002)
s <- stat_smooth(aes(x=x, y=y), se = TRUE)
d <- ggplot(data) + geom_point(aes(x=x,y=y)) + scale_y_log10() + ggtitle("Attenuation of Radation by Iron") + xlab("Thickness (mm)") + ylab("Count Rate (counts per second)")
d <- d + s + bars
print(d)

